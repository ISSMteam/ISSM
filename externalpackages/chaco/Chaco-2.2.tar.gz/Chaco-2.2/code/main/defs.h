#define	max(A, B)	((A) > (B) ? (A) : (B))
#define	min(A, B)	((A) < (B) ? (A) : (B))
#define sign(A)		((A) <  0  ? -1  :  1)
#define absval(A)	((A) <  0  ? -(A): (A))
#define TRUE		1
#define FALSE		0

/* Define constants that are needed in various places */
#define	PI	3.141592653589793
#define	TWOPI	6.283185307179586
#define HALFPI  1.570796326794896
